import Page1 from "./Page1/page";

export default function Home() {
  return (
    <>
      <Page1 />
    </>
  );
}
